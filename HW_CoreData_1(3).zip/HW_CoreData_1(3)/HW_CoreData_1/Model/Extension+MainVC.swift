//
//  Extension+MainVC.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 06.09.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

extension MainViewController {
    func fillDataModel() {
        let context = dataManager.getContext()
        
        //Createing Clubs Objects
        let club = dataManager.createObject(from: Club.self)
        club.name = "Dinamo"
        let club1 = dataManager.createObject(from: Club.self)
        club1.name = "Milan"
        let club2 = dataManager.createObject(from: Club.self)
        club2.name = "Moscow-D"
        let club3 = dataManager.createObject(from: Club.self)
        club3.name = "GasMias"
        
        let player = dataManager.createObject(from: Player.self)
        let image = dataManager.createObject(from: Image.self)
        image.image = #imageLiteral(resourceName: "image-5")
        player.image = image
        player.club = club
        player.age = 20
        player.fullName = "Ka Ka Ka Ka"
        player.nationality = "Ukraine"
        player.playerNumber = "56"
        player.position = "Forward"
        player.inPLay = "Bench"
        
        let player1 = dataManager.createObject(from: Player.self)
        let image1 = dataManager.createObject(from: Image.self)
        image1.image = #imageLiteral(resourceName: "image-3")
        player1.image = image1
        player1.club = club2
        player1.age = 27
        player1.fullName = "La la la ls"
        player1.nationality = "Germani"
        player1.playerNumber = "56"
        player1.position = "Midfielder"
        player1.inPLay = "In Play"
        
        let player2 = dataManager.createObject(from: Player.self)
        let image2 = dataManager.createObject(from: Image.self)
        image2.image = #imageLiteral(resourceName: "image-10")
        player2.image = image2
        player2.club = club1
        player2.age = 29
        player2.fullName = "Ta ta ta ta"
        player2.nationality = "Italy"
        player2.playerNumber = "88"
        player2.position = "Defender"
        player2.inPLay = "Bench"
        
        let player3 = dataManager.createObject(from: Player.self)
        let image3 = dataManager.createObject(from: Image.self)
        image3.image = #imageLiteral(resourceName: "image-1")
        player3.image = image3
        player3.club = club3
        player3.age = 34
        player3.fullName = "Sa sa sa sa"
        player3.nationality = "Franch"
        player3.playerNumber = "76"
        player3.position = "Goalkeeper"
        player3.inPLay = "In Play"
        
        let player4 = dataManager.createObject(from: Player.self)
        let image4 = dataManager.createObject(from: Image.self)
        image4.image = #imageLiteral(resourceName: "image-5")
        player4.image = image4
        player4.club = club
        player4.age = 20
        player4.fullName = "Ka Ka Ka Ka"
        player4.nationality = "Ukraine"
        player4.playerNumber = "56"
        player4.position = "Forward"
        player4.inPLay = "Bench"
        
        let player5 = dataManager.createObject(from: Player.self)
        let image5 = dataManager.createObject(from: Image.self)
        image5.image = #imageLiteral(resourceName: "image-10")
        player5.image = image5
        player5.club = club
        player5.age = 20
        player5.fullName = "Ma Ma Ma Ma"
        player5.nationality = "Ukraine"
        player5.playerNumber = "56"
        player5.position = "Forward"
        player5.inPLay = "Bench"
        
        let player6 = dataManager.createObject(from: Player.self)
        let image6 = dataManager.createObject(from: Image.self)
        image6.image = #imageLiteral(resourceName: "image-2")
        player6.image = image6
        player6.club = club2
        player6.age = 27
        player6.fullName = "Pa Pa Pa Pa"
        player6.nationality = "Germani"
        player6.playerNumber = "56"
        player6.position = "Midfielder"
        player6.inPLay = "Bench"
        
        let player7 = dataManager.createObject(from: Player.self)
        let image7 = dataManager.createObject(from: Image.self)
        image7.image = #imageLiteral(resourceName: "image-10")
        player7.image = image7
        player7.club = club1
        player7.age = 29
        player7.fullName = "Ha Ha Ha Ha"
        player7.nationality = "Italy"
        player7.playerNumber = "88"
        player7.position = "Defender"
        player7.inPLay = "In Play"
        
        let player8 = dataManager.createObject(from: Player.self)
        let image8 = dataManager.createObject(from: Image.self)
        image8.image = #imageLiteral(resourceName: "image-9")
        player8.image = image8
        player8.club = club
        player8.age = 34
        player8.fullName = "Va Va Va Va"
        player8.nationality = "Franch"
        player8.playerNumber = "76"
        player8.position = "Goalkeeper"
        player8.inPLay = "Bench"
        
        let player9 = dataManager.createObject(from: Player.self)
        let image9 = dataManager.createObject(from: Image.self)
        image9.image = #imageLiteral(resourceName: "image-5")
        player9.image = image9
        player9.club = club3
        player9.age = 20
        player9.fullName = "Ba Ba Ba Ba"
        player9.nationality = "Ukraine"
        player9.playerNumber = "56"
        player9.position = "Forward"
        player9.inPLay = "In Play"
        
        dataManager.save(context: context)
    }
}
