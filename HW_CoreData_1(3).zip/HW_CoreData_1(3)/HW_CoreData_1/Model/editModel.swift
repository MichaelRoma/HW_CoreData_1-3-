//
//  editModel.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 23.09.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

struct PlayerModelForEdit {
    var age: Int16 = 0
    var fullName = ""
    var inPlay = ""
}
