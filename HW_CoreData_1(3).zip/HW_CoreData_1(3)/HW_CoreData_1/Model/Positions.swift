//
//  Positions.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 12.09.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//
struct Positions {
    static let positions = ["Forward",
                            "Midfielder",
                            "Defender",
                            "Goalkeeper"
    ]
}
