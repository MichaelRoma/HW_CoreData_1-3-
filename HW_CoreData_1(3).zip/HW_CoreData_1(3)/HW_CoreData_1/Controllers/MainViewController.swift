//
//  MainViewController.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 18.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit
import CoreData

class MainViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var inPLAYSsegmentedControll: UISegmentedControl!
    
    var dataManager: CoreDataManager!
    var fetchedResultController: NSFetchedResultsController<Player>!
    
    private var items = [Player]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK: Использовать только один раз, желательно, иначе будет каждый раз добавляться новые игроки.
        //   fillDataModel()
        
        tableView.delegate = self
        tableView.dataSource = self
        navigationItem.title = "Team Manager"
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addPlayer)
        )
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .search,
            target: self,
            action: #selector(filterPlayers))
        
        
        fetchData()
    }
    
    @IBAction func inPlaySegmentedControllPressed(_ sender: Any) {
        switch inPLAYSsegmentedControll.selectedSegmentIndex {
        case 0:
            fetchData()
        case 1:
            fetchData(predicate: NSCompoundPredicate(andPredicateWithSubpredicates: [NSPredicate(format: "%K LIKE %@", #keyPath(Player.inPLay), "In Play")]))
        case 2:
            fetchData(predicate: NSCompoundPredicate(andPredicateWithSubpredicates: [NSPredicate(format: "%K LIKE %@", #keyPath(Player.inPLay), "Bench")]))
        default:
            break
        }
        
        tableView.reloadData()
    }
    
    @objc func addPlayer() {
        let storyboard = UIStoryboard(name: "PlayerViewController", bundle: Bundle.main)
        guard let plaeyVC = storyboard.instantiateViewController(identifier: "PlayerViewController") as? PlayerViewController else {
            return
        }
        plaeyVC.dataManager = dataManager
        navigationController?.pushViewController(plaeyVC, animated: true )
    }
    
    @objc func filterPlayers() {
        let searchVC = SearchViewController()
        searchVC.delegate = self
        searchVC.modalTransitionStyle = .crossDissolve
        searchVC.modalPresentationStyle = .overCurrentContext
        present(searchVC, animated: true)
    }
    
    private func fetchData(predicate: NSCompoundPredicate? = nil) {
        fetchedResultController = dataManager.fetchDataWithController(for: Player.self, sectionNameKeyPath: "position", predicate: predicate)
        
        fetchedResultController.delegate = self
        fetchedObjectsCheck()
    }
    
    private func fetchedObjectsCheck() {
        guard let objects = fetchedResultController.fetchedObjects else {
            return
        }
        
        if objects.count > 0 {
            tableView.isHidden = false
        } else {
            tableView.isHidden = true
        }
    }
}

extension MainViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let item = self.fetchedResultController.object(at: indexPath)
        
        let deleteAction = UITableViewRowAction(style: .destructive, title: "DELETE") { (deleteAction, indexPath) in
            self.dataManager.delete(object: item)
        }
        
        let editAction = UITableViewRowAction(style: .normal, title: "EDIT") { (editAction, indexPath) in
            let storyboard = UIStoryboard(name: "PlayerViewController", bundle: Bundle.main)
            guard let vc = storyboard.instantiateViewController(identifier: "PlayerViewController") as? PlayerViewController else {
                return
            }
            vc.dataManager = self.dataManager
            vc.editPlayer = item
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        let inPlayAction = UITableViewRowAction(style: .normal, title: item.inPLay == "In Play" ? "To Bench" : "To Play") { (inPlayAction, indexPath) in
            item.inPLay = inPlayAction.title == "To Bench" ? "Bench" : "In Play"
            let context = self.dataManager.getContext()
            self.dataManager.save(context: context)
        }
        
        deleteAction.backgroundColor = .red
        editAction.backgroundColor = .orange
        inPlayAction.backgroundColor = .purple
        
        return [deleteAction, editAction, inPlayAction]
    }
    
}

extension MainViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let sections = fetchedResultController.sections else {
            return 0
        }
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        guard let sections = fetchedResultController.sections else {
            return nil
        }
        return sections[section].name
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sections = fetchedResultController.sections else {
            return 0
        }
        return sections[section].numberOfObjects
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if let cell = cell as? ItemTableViewCell {
            let item = fetchedResultController.object(at: indexPath)
            cell.configurator(with: item)
        }
        return cell
    }
}

extension MainViewController: SearchDelegate {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate) {
        fetchData(predicate: predicate)
        tableView.reloadData()
    }    
}

// MARK: NSFetchedResultsControllerDelegate
extension MainViewController: NSFetchedResultsControllerDelegate {
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
            
            switch type {
            case .insert:
                tableView.insertSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .fade)
            case .delete:
                tableView.deleteSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .fade)
            default:
                return
            }
            
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch type {
        case .insert:
            if let indexPath = newIndexPath {
                tableView.insertRows(at: [indexPath], with: .fade)
                fetchedObjectsCheck()
            }
            
        case .delete:
            if let indexPath = indexPath {
                tableView.deleteRows(at: [indexPath], with: .fade)
                fetchedObjectsCheck()
            }
            
        case .update:
            if let indexPath = indexPath {
                let cell = tableView.cellForRow(at: indexPath) as! ItemTableViewCell
                let item = fetchedResultController.object(at: indexPath as IndexPath)
                cell.configurator(with: item)
            }
            
        case .move:
            if let indexPath = indexPath {
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
            if let indexPath = newIndexPath {
                tableView.insertRows(at: [indexPath], with: .fade)
            }
        }
        
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
}
